
import glob

myfiles = glob.glob("*.txt")

print(myfiles)